// Login functionality
function userLogin() {
    document.getElementById("login-form").addEventListener("submit", async (e) => {
        e.preventDefault();
        const username = document.getElementById("username").value;
        const otp = document.getElementById("otp").value;

        try {
            const response = await fetch(`https://assignment.stage.crafto.app/login`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, otp })
            });
            const contentType = response.headers.get("Content-Type");
            let data;

            if (contentType && contentType.includes("application/json")) {
                data = await response.json();
            } else {
                data = await response.text();
            }
            // Handle response
            if (data.token) {
                sessionStorage.setItem("token", data.token);
                location.href = "quotes.html";
            } else if (data === "Wrong otp") {
                alert(data);
            } else {
                alert("Login failed!");
            }
        } catch (error) {
            console.error("Error during login:", error);
            alert("An error occurred. Please try again.");
        }
    });
}



if (location.pathname.includes("quotes.html")) {
    document.getElementById("loader").classList.add("active-loader");
    let offset = 0;
    const limit = 20;
    let isLoading = false;

    async function loadQuotes() {
        const token = sessionStorage.getItem("token");
        const response = await fetch(`https://assignment.stage.crafto.app/getQuotes?limit=${limit}&offset=${offset}`, {
            headers: { Authorization: token }
        });

        const quotes = await response.json();
        if (quotes.length === 0) {
            window.removeEventListener("scroll", handleScroll);
            return;
        }

        const quoteList = document.getElementById("quote-list");
        const quoteData = quotes.data;
        quoteData.forEach(quote => {
            if (quote.mediaUrl == null || quote.mediaUrl == '') {
                const div = document.createElement("div");
                div.className = "quote";
                div.innerHTML = `
                    <img src="img/No_Image_Available.jpg" alt="Quote Image">
                    <div class="quote-overlay">
                        <p>${quote.text.toLocaleUpperCase()}</p>
                        <p><small>Author:- ${quote.username}</small><small>${new Date(quote.createdAt).toLocaleString()}</small</p>
                    </div>
                `;
                quoteList.appendChild(div);
            } else {
                const div = document.createElement("div");
                div.className = "quote";
                div.innerHTML = `
                    <img src="${quote.mediaUrl}" alt="Quote Image">
                    <div class="quote-overlay">
                        <p>${quote.text.toLocaleUpperCase()}</p>
                         <p><small>Author:- ${quote.username}</small><small>${new Date(quote.createdAt).toLocaleString()}</small</p>
                    </div>
                `;
                quoteList.appendChild(div);
            }
            
        });

        offset += limit;
        setTimeout(() => {
            document.getElementById("loader").classList.remove("active-loader");
        }, 2000);
    }

    function handleScroll() {
        if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 50 && !isLoading) {
            isLoading = true;
            loadQuotes().then(() => {
                isLoading = false;
            });
        }
    }

    window.addEventListener("scroll", handleScroll);
    loadQuotes();
}


//quote create
if (location.pathname.includes("create-quote.html")) {
    document.getElementById("quote-form").addEventListener("submit", async (e) => {
        e.preventDefault();

        const text = document.getElementById("quote-text").value;
        const file = document.getElementById("quote-image").files[0];
        const token = sessionStorage.getItem("token");

        if (!file) {
            alert("Please select a file.");
            return;
        }
        const formData = new FormData();
        formData.append("file", file);

        // Step 1:
        const uploadResponse = await fetch('https://crafto.app/crafto/v1.0/media/assignment/upload', {
            method: "POST",
            body: formData,
        });

        const uploadData = await uploadResponse.json();

        console.log(uploadData);

        if (!uploadData || !uploadData[0] || !uploadData[0].url) {
            console.error("Image upload failed:", uploadData);
            alert("Image upload failed!");
            return;
        }

        // Step 2:
        const response = await fetch('https://assignment.stage.crafto.app/postQuote', {
            method: "POST",
            headers: {
                Authorization: token,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                text: text,
                mediaUrl: uploadData[0].url 
            })
        });

        if (response.ok) {
            alert("Quote created successfully!");
            location.href = "quotes.html";
        } else {
            alert("Failed to create quote.");
        }
    });
}




